var canvas = document.getElementById('c1');
var ctx = canvas.getContext('2d');
//var mas = new Array(100).fill(0).map(row => new Array(100).fill(0));
var mas = new Array(100).fill(0).map(function(){return new Array(100).fill(0)});

var count=0;
var stopIteration = false;

canvas.onclick = function(event){
	var x = Math.floor(event.offsetX/10);
	var y = Math.floor(event.offsetY/10);
	console.log(x);
	console.log(y);
	mas[y][x]=mas[y][x]+1;
	drawField();
}

function getColor(age){
	age = age - 1 > 10 ? 10 : age - 1;
	var collorAge = [
		"rgb(112,48,160)",
		"rgb(0,32,96)",
		"rgb(0,112,192)",
		"rgb(0,176,240)",
		"rgb(0,176,80)",
		"rgb(146,208,80)",
		"rgb(255,255,0)",
		"rgb(255,192,0)",
		"rgb(255,0,0)",
		"rgb(192,0,0)"
	];
	return collorAge[age];
}

function drawField(){
	ctx.clearRect(0, 0, 500, 500);
	for (var i=0; i<50; i++){
		for (var j=0; j<50; j++){
			if (mas[i][j]>0){
				ctx.fillStyle = getColor(mas[i][j]);
				ctx.fillRect(j*10, i*10, 10, 10);
			}
		}
	}
}

function stopLife(){
	stopIteration = true;
}

function startLife(){
	//моделирование жизни
	var mas2 = [];
	for (var i=0; i<50; i++){
		mas2[i]=[];
		for (var j=0; j<50; j++){
			var neighbors = 0;
			if (mas[fpm(i)-1][j]>0) neighbors++;//up
			if (mas[i][fpp(j)+1]>0) neighbors++;//right
			if (mas[fpp(i)+1][j]>0) neighbors++;//bottom
			if (mas[i][fpm(j)-1]>0) neighbors++;//left
			if (mas[fpm(i)-1][fpp(j)+1]>0) neighbors++;
			if (mas[fpp(i)+1][fpp(j)+1]>0) neighbors++;
			if (mas[fpp(i)+1][fpm(j)-1]>0) neighbors++;
			if (mas[fpm(i)-1][fpm(j)-1]>0) neighbors++;
			//(neighbors==2 || neighbors==3) ? mas2[i][j]=1 : mas2[i][j]=0;
			//(neighbors === 2 || neighbors === 3) ? mas2[i][j]=mas[i][j] + 1 : mas2[i][j]=0;
			//(neighbors > 2) ? mas2[i][j]= mas[i][j] + 1 : mas2[i][j]=0;
			(neighbors > 2) ? mas2[i][j] = (mas[i][j] + 1 > 11 ? 0 : mas[i][j] + 1) : mas2[i][j]=0;
		}
	}
	mas = mas2;
	drawField();
	setTimeout(function(){if (!stopIteration) startLife()}, 500);

	document.getElementById('count').innerHTML = ++count;
	stopIteration = false;
}

function fpm(i){
	return i === 0 ? 50 : i;
}
function fpp(i){
	return i === 49 ? -1 : i;
}

